# MCCore

Production-ready competitive core plugin for the **Minecraft Clans (MCC)** project.

- Paper **1.21.x**
- Java **21**
- Gradle **Kotlin DSL**
- SQLite (default) / MySQL via HikariCP
- WorldGuard for region geometry

## Build

```bash
./gradlew build
# Output: build/libs/MCCore-1.0.0.jar
```

## Architecture

```
com.mccore
├── MCCorePlugin           # Bootstrap, DI container, lifecycle
├── clan                   # Clan domain model + service
├── territory              # Region domain (BASE / CHECKPOINT / CASTLE) + WorldGuard adapter
├── combat                 # Kill tracking, anti-farm, cooldowns
├── event                  # Event scheduler (Sat 14-18), state machine, crash recovery
├── respawn                # Respawn rules, elimination, spectator handling
├── items                  # 8 unique clan special items (PDC, anti-dupe)
├── quests                 # Clan-wide synced quests
├── persistence            # Hikari pool, repositories, migrations
├── ui                     # Scoreboard, bossbar, actionbar (Adventure / MiniMessage)
├── admin                  # /mcc admin commands
├── command                # Command dispatcher + subcommands
├── listener               # Bukkit listeners (separated by concern)
├── config                 # YAML config wrappers
└── util                   # Color parser, async helpers, logging
```

### Design principles

- **Service layer + repository pattern** — no god classes.
- **Constructor DI** — a tiny `ServiceContainer` wires everything in `onEnable`.
- **Async-only DB access** — Hikari + `CompletableFuture`, never on main thread.
- **Bukkit API only on main thread** — async tasks hop back via `runTask`.
- **Atomic inventory ops** — snapshot + diff, no partial writes.
- **PersistentDataContainer** for clan items with UUID binding (anti-dupe).
- **Event-driven** — internal `MCCEventBus` for cross-module signals
  (capture started, points awarded, item transferred …).

### Configurability

Everything is configurable. Nothing about clans, regions, points, or events
is hardcoded.

- `config.yml` — global settings (DB, event window, point rules, anti-farm).
- `clans.yml` — initial clans (also fully manageable in-game).
- `regions.yml` — region bindings to WorldGuard regions.
- `messages.yml` — all user-facing text (MiniMessage).
- All values reloadable with `/mcc reload`.

## Commands

See `plugin.yml` for the full list. Top-level: `/mcc <subcommand>`.

| Command | Purpose |
|---|---|
| `/mcc clan create\|delete\|setname\|setcolor\|setspawn\|setleader\|addplayer\|removeplayer\|info\|list` | Clan management |
| `/mcc region create\|delete\|setwg\|setname\|setowner\|setpoints\|info\|list` | Region management |
| `/mcc event start\|stop\|status\|forcestart\|forcestop` | Event control |
| `/mcc reload\|save\|debug\|reset` | Admin |

## Permissions

```
mccore.admin           # all admin commands
mccore.clan.manage     # clan CRUD
mccore.region.manage   # region CRUD
mccore.event.manage    # event control
mccore.player          # default for all players
```

## Persistence

SQLite by default (`plugins/MCCore/data.db`). Switch to MySQL via `config.yml`.
Schema is created/migrated automatically on startup
(`persistence/SchemaMigrator.java`).

## Anti-Exploit

- Kill cooldowns + diminishing returns per victim per event.
- Combat-log → eliminated on next join during event.
- Item movement intercepted (hopper, item frame, drop on death) for clan items.
- Atomic inventory transactions.
- Audit log table (`mccore_audit`) for points, items, region ownership.

## Testing

JUnit 5 + Mockito. Unit tests for services, integration tests for repositories
(in-memory SQLite). See `src/test/java/com/mccore/`.

## TODO (next iterations)

- PlaceholderAPI integration
- Discord webhook for event start/end and item transfers
- Web dashboard (read-only) over the audit log
- Per-clan custom enchantments for special items
