package com.mccore.config;

import com.mccore.util.ColorParser;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;

/**
 * Wraps config.yml, clans.yml, regions.yml. Reloadable.
 * No business logic — pure read/write.
 */
public final class ConfigService {

    private final JavaPlugin plugin;
    private FileConfiguration main;
    private YamlConfiguration clans;
    private YamlConfiguration regions;

    private final File clansFile;
    private final File regionsFile;

    public ConfigService(JavaPlugin plugin) {
        this.plugin = plugin;
        this.clansFile = new File(plugin.getDataFolder(), "clans.yml");
        this.regionsFile = new File(plugin.getDataFolder(), "regions.yml");
        reload();
    }

    public void reload() {
        plugin.reloadConfig();
        this.main = plugin.getConfig();
        this.clans = YamlConfiguration.loadConfiguration(clansFile);
        this.regions = YamlConfiguration.loadConfiguration(regionsFile);
    }

    public void saveClans() {
        try { clans.save(clansFile); }
        catch (IOException e) { plugin.getLogger().severe("Save clans.yml: " + e.getMessage()); }
    }

    public void saveRegions() {
        try { regions.save(regionsFile); }
        catch (IOException e) { plugin.getLogger().severe("Save regions.yml: " + e.getMessage()); }
    }

    public FileConfiguration main() { return main; }
    public YamlConfiguration clans() { return clans; }
    public YamlConfiguration regions() { return regions; }

    /* ---------- typed accessors ---------- */

    public String storageType() { return main.getString("storage.type", "sqlite"); }
    public boolean debug() { return main.getBoolean("debug", false); }

    public int pointsKill()             { return main.getInt("points.kill", 2); }
    public int pointsDeath()            { return main.getInt("points.death", -3); }
    public int pointsOwnBaseLost()      { return main.getInt("points.own-base-lost-per-min", -1); }
    public int pointsEnemyBaseHeld()    { return main.getInt("points.enemy-base-held-per-min", 2); }
    public int pointsCheckpointHeld()   { return main.getInt("points.checkpoint-held-per-min", 2); }
    public int pointsCastleHeld()       { return main.getInt("points.castle-held-per-min", 3); }

    public int killCooldownSeconds()    { return main.getInt("anti-farm.kill-cooldown-seconds", 120); }
    public boolean diminishingEnabled() { return main.getBoolean("anti-farm.diminishing-returns.enabled", true); }

    public int normalDeathLossPercent() { return main.getInt("inventory.normal-death-loss-percent", 20); }
    public boolean elimLosesAll()       { return main.getBoolean("inventory.elimination-loses-everything", true); }

    public int globalSpecialItemCount() { return main.getInt("items.count", 8); }

    @Nullable
    public TextColor parseColor(String raw) {
        return ColorParser.parse(raw);
    }

    public Location readLocation(String path, YamlConfiguration cfg) {
        var sec = cfg.getConfigurationSection(path);
        if (sec == null) return null;
        var world = plugin.getServer().getWorld(sec.getString("world", "world"));
        if (world == null) return null;
        return new Location(world,
                sec.getDouble("x"), sec.getDouble("y"), sec.getDouble("z"),
                (float) sec.getDouble("yaw", 0), (float) sec.getDouble("pitch", 0));
    }

    public void writeLocation(String path, YamlConfiguration cfg, Location loc) {
        cfg.set(path + ".world", loc.getWorld().getName());
        cfg.set(path + ".x", loc.getX());
        cfg.set(path + ".y", loc.getY());
        cfg.set(path + ".z", loc.getZ());
        cfg.set(path + ".yaw", loc.getYaw());
        cfg.set(path + ".pitch", loc.getPitch());
    }
}
