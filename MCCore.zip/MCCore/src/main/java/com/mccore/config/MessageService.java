package com.mccore.config;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Map;

/**
 * MiniMessage-based message provider. All user-visible text routes through here.
 */
public final class MessageService {

    private final JavaPlugin plugin;
    private final ConfigService configService;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private YamlConfiguration messages;

    public MessageService(JavaPlugin plugin, ConfigService configService) {
        this.plugin = plugin;
        this.configService = configService;
        reload();
    }

    public void reload() {
        var f = new File(plugin.getDataFolder(), "messages.yml");
        this.messages = YamlConfiguration.loadConfiguration(f);
    }

    public Component get(String key, Map<String, String> placeholders) {
        var raw = messages.getString(key, key);
        var prefix = messages.getString("prefix", "");
        var resolvers = placeholders.entrySet().stream()
                .map(e -> (TagResolver) Placeholder.parsed(e.getKey(), e.getValue()))
                .toArray(TagResolver[]::new);
        return mini.deserialize(prefix + raw, TagResolver.resolver(resolvers));
    }

    public Component get(String key) {
        return get(key, Map.of());
    }

    public MiniMessage mini() { return mini; }
}
