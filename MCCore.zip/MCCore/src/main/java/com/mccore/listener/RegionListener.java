package com.mccore.listener;

import com.mccore.ServiceContainer;
import org.bukkit.event.Listener;

/**
 * Reserved for region capture progression triggers driven by player movement.
 * The capture loop itself runs as a scheduled task — this listener is a placeholder
 * for fast-path "player entered region" optimizations.
 */
public final class RegionListener implements Listener {

    @SuppressWarnings("unused")
    private final ServiceContainer services;

    public RegionListener(ServiceContainer s) { this.services = s; }

    // TODO: subscribe to PlayerMoveEvent at low frequency or use WG region-enter events.
}
