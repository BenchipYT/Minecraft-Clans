package com.mccore.listener;

import com.mccore.ServiceContainer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * Translates Minecraft death events into combat scoring + respawn handling.
 */
public final class CombatListener implements Listener {

    private final ServiceContainer services;

    public CombatListener(ServiceContainer s) { this.services = s; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        var victim = e.getEntity();
        var killer = victim.getKiller();
        if (killer != null) services.combatService().onKill(killer, victim);
        services.respawnService().handleDeath(victim);
    }
}
