package com.mccore.listener;

import com.mccore.ServiceContainer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

/**
 * Anti-dupe / anti-hopper for clan special items.
 */
public final class InventoryListener implements Listener {

    private final ServiceContainer services;

    public InventoryListener(ServiceContainer s) { this.services = s; }

    @EventHandler
    public void onHopper(InventoryMoveItemEvent e) {
        if (!services.config().main().getBoolean("items.prevent-hopper-pickup", true)) return;
        if (services.clanItemService().isClanItem(e.getItem())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        var stack = e.getItemDrop().getItemStack();
        var uuid = services.clanItemService().readUuid(stack);
        if (uuid == null) return;
        var policy = services.config().main().getString("items.drop-on-death-policy", "BIND_TO_CLAN");
        if ("DELETE".equalsIgnoreCase(policy)) {
            e.setCancelled(true);
            stack.setAmount(0);
        }
        // BIND_TO_CLAN / DROP: allowed (movement still tracked).
    }
}
