package com.mccore.listener;

import com.mccore.ServiceContainer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public final class PlayerStateListener implements Listener {

    private final ServiceContainer services;

    public PlayerStateListener(ServiceContainer s) { this.services = s; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        // Hook for UI bootstrapping.
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        var loc = services.respawnService().pickRespawn(e.getPlayer());
        if (loc != null) e.setRespawnLocation(loc);
    }
}
