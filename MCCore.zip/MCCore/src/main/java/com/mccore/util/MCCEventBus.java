package com.mccore.util;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Tiny synchronous in-process event bus for cross-module signals.
 * Listeners run on the calling thread — keep handlers cheap.
 */
public final class MCCEventBus {

    private final Map<Class<?>, List<Consumer<Object>>> listeners = new ConcurrentHashMap<>();

    @SuppressWarnings("unchecked")
    public <T> void subscribe(Class<T> type, Consumer<T> handler) {
        listeners.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>())
                .add((Consumer<Object>) handler);
    }

    public void publish(Object event) {
        var list = listeners.get(event.getClass());
        if (list == null) return;
        for (var h : list) {
            try { h.accept(event); }
            catch (Throwable t) { t.printStackTrace(); }
        }
    }
}
