package com.mccore.util;

import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.jetbrains.annotations.Nullable;

/**
 * Parses colors as either a NamedTextColor name (e.g. "RED") or hex (e.g. "#FFAA00").
 */
public final class ColorParser {
    private ColorParser() {}

    @Nullable
    public static TextColor parse(String raw) {
        if (raw == null || raw.isBlank()) return null;
        var s = raw.trim();
        if (s.startsWith("#")) {
            try { return TextColor.fromHexString(s); }
            catch (Exception e) { return null; }
        }
        var named = NamedTextColor.NAMES.value(s.toLowerCase());
        return named;
    }
}
