package com.mccore.util;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Helpers to keep Bukkit API on the main thread and DB work off it.
 */
public final class AsyncUtil {
    private AsyncUtil() {}

    public static <T> CompletableFuture<T> async(JavaPlugin plugin, Supplier<T> work) {
        var fut = new CompletableFuture<T>();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try { fut.complete(work.get()); }
            catch (Throwable t) { fut.completeExceptionally(t); }
        });
        return fut;
    }

    public static void sync(JavaPlugin plugin, Runnable r) {
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(plugin, r);
    }
}
