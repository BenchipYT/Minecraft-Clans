package com.mccore.clan;

import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Location;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Domain model. Mutable through ClanService only.
 */
public final class Clan {

    private final String id;
    private String displayName;
    private TextColor color;
    private int maxMembers;
    private @Nullable UUID leaderUuid;
    private @Nullable Location spawn;
    private int points;

    private final Set<UUID> members = new LinkedHashSet<>();
    private final Set<String> ownedRegions = new LinkedHashSet<>();
    private @Nullable UUID ownedSpecialItem;

    public Clan(String id, String displayName, TextColor color, int maxMembers) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.maxMembers = maxMembers;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public void setDisplayName(String n) { this.displayName = n; }
    public TextColor color() { return color; }
    public void setColor(TextColor c) { this.color = c; }
    public int maxMembers() { return maxMembers; }
    public void setMaxMembers(int m) { this.maxMembers = m; }
    public @Nullable UUID leaderUuid() { return leaderUuid; }
    public void setLeaderUuid(@Nullable UUID u) { this.leaderUuid = u; }
    public @Nullable Location spawn() { return spawn; }
    public void setSpawn(@Nullable Location s) { this.spawn = s; }
    public int points() { return points; }
    public void addPoints(int delta) { this.points += delta; }
    public void setPoints(int p) { this.points = p; }
    public Set<UUID> members() { return members; }
    public Set<String> ownedRegions() { return ownedRegions; }
    public @Nullable UUID ownedSpecialItem() { return ownedSpecialItem; }
    public void setOwnedSpecialItem(@Nullable UUID i) { this.ownedSpecialItem = i; }
}
