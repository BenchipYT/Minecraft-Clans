package com.mccore.clan;

import com.mccore.persistence.DatabaseManager;
import com.mccore.util.ColorParser;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * SQL repository for clans. All methods are blocking — call from async context.
 */
public final class ClanRepository {

    private final DatabaseManager db;

    public ClanRepository(DatabaseManager db) { this.db = db; }

    public List<Clan> loadAllClans() {
        var clans = new HashMap<String, Clan>();
        try (Connection c = db.borrow()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT * FROM mccore_clans");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    var color = ColorParser.parse(rs.getString("color"));
                    var clan = new Clan(rs.getString("id"),
                            rs.getString("display_name"),
                            color != null ? color : TextColor.color(0xFFFFFF),
                            rs.getInt("max_members"));
                    var leader = rs.getString("leader_uuid");
                    if (leader != null) clan.setLeaderUuid(UUID.fromString(leader));
                    clan.setPoints(rs.getInt("points"));
                    var world = rs.getString("spawn_world");
                    if (world != null && Bukkit.getWorld(world) != null) {
                        clan.setSpawn(new Location(Bukkit.getWorld(world),
                                rs.getDouble("spawn_x"),
                                rs.getDouble("spawn_y"),
                                rs.getDouble("spawn_z"),
                                rs.getFloat("spawn_yaw"),
                                rs.getFloat("spawn_pitch")));
                    }
                    clans.put(clan.id(), clan);
                }
            }
            try (PreparedStatement ps = c.prepareStatement("SELECT uuid, clan_id FROM mccore_clan_members");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    var clan = clans.get(rs.getString("clan_id"));
                    if (clan != null) clan.members().add(UUID.fromString(rs.getString("uuid")));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("loadAllClans", e);
        }
        return new ArrayList<>(clans.values());
    }

    public void upsert(Clan c) {
        var sql = """
            INSERT INTO mccore_clans
              (id, display_name, color, max_members, leader_uuid,
               spawn_world, spawn_x, spawn_y, spawn_z, spawn_yaw, spawn_pitch, points)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              display_name=excluded.display_name,
              color=excluded.color,
              max_members=excluded.max_members,
              leader_uuid=excluded.leader_uuid,
              spawn_world=excluded.spawn_world,
              spawn_x=excluded.spawn_x, spawn_y=excluded.spawn_y, spawn_z=excluded.spawn_z,
              spawn_yaw=excluded.spawn_yaw, spawn_pitch=excluded.spawn_pitch,
              points=excluded.points
            """;
        try (Connection con = db.borrow(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.id());
            ps.setString(2, c.displayName());
            ps.setString(3, c.color().asHexString());
            ps.setInt(4, c.maxMembers());
            ps.setString(5, c.leaderUuid() != null ? c.leaderUuid().toString() : null);
            var s = c.spawn();
            ps.setString(6, s != null ? s.getWorld().getName() : null);
            ps.setDouble(7, s != null ? s.getX() : 0);
            ps.setDouble(8, s != null ? s.getY() : 0);
            ps.setDouble(9, s != null ? s.getZ() : 0);
            ps.setFloat(10, s != null ? s.getYaw() : 0);
            ps.setFloat(11, s != null ? s.getPitch() : 0);
            ps.setInt(12, c.points());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("upsert clan " + c.id(), e);
        }
    }

    public void delete(String id) {
        try (Connection con = db.borrow()) {
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM mccore_clan_members WHERE clan_id=?")) {
                ps.setString(1, id); ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM mccore_clans WHERE id=?")) {
                ps.setString(1, id); ps.executeUpdate();
            }
        } catch (SQLException e) { throw new RuntimeException("delete clan " + id, e); }
    }

    public void upsertMember(UUID player, String clanId) {
        var sql = """
            INSERT INTO mccore_clan_members (uuid, clan_id, joined_at) VALUES (?,?,?)
            ON CONFLICT(uuid) DO UPDATE SET clan_id=excluded.clan_id
            """;
        try (Connection con = db.borrow(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, player.toString());
            ps.setString(2, clanId);
            ps.setLong(3, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("upsertMember", e); }
    }

    public void deleteMember(UUID player) {
        try (Connection con = db.borrow();
             PreparedStatement ps = con.prepareStatement("DELETE FROM mccore_clan_members WHERE uuid=?")) {
            ps.setString(1, player.toString());
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("deleteMember", e); }
    }
}
