package com.mccore.clan;

import com.mccore.config.ConfigService;
import com.mccore.persistence.DatabaseManager;
import com.mccore.util.AsyncUtil;
import com.mccore.util.MCCEventBus;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Clan domain service. Single source of truth for clan state at runtime.
 * All persistence happens via {@link ClanRepository} on the async pool.
 */
public final class ClanService {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final ClanRepository repo;
    private final MCCEventBus eventBus;

    private final Map<String, Clan> clans = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerToClan = new ConcurrentHashMap<>();

    public ClanService(JavaPlugin plugin, ConfigService config, ClanRepository repo, MCCEventBus eventBus) {
        this.plugin = plugin;
        this.config = config;
        this.repo = repo;
        this.eventBus = eventBus;
    }

    public void loadAll() {
        // Seed from clans.yml on first boot.
        var section = config.clans().getConfigurationSection("clans");
        if (section != null) {
            for (var id : section.getKeys(false)) {
                if (clans.containsKey(id)) continue;
                var sec = section.getConfigurationSection(id);
                var color = config.parseColor(sec.getString("color", "WHITE"));
                var clan = new Clan(id,
                        sec.getString("display-name", id),
                        color != null ? color : TextColor.color(0xFFFFFF),
                        sec.getInt("max-members", 20));
                clan.setSpawn(config.readLocation("spawn", (org.bukkit.configuration.file.YamlConfiguration) sec));
                clans.put(id, clan);
            }
        }

        // Then merge persisted state (DB is authoritative for runtime values).
        AsyncUtil.async(plugin, repo::loadAllClans).thenAccept(loaded -> {
            for (var c : loaded) {
                clans.put(c.id(), c);
                for (var m : c.members()) playerToClan.put(m, c.id());
            }
            plugin.getLogger().info("Loaded " + clans.size() + " clans.");
        });
    }

    public Collection<Clan> all() { return clans.values(); }

    public @Nullable Clan get(String id) { return clans.get(id); }

    public @Nullable Clan ofPlayer(UUID player) {
        var id = playerToClan.get(player);
        return id == null ? null : clans.get(id);
    }

    public boolean create(String id, String displayName, TextColor color) {
        if (clans.containsKey(id)) return false;
        var c = new Clan(id, displayName, color, config.main().getInt("clan.default-max-members", 20));
        clans.put(id, c);
        AsyncUtil.async(plugin, () -> { repo.upsert(c); return null; });
        return true;
    }

    public boolean delete(String id) {
        var removed = clans.remove(id);
        if (removed == null) return false;
        for (var m : removed.members()) playerToClan.remove(m);
        AsyncUtil.async(plugin, () -> { repo.delete(id); return null; });
        return true;
    }

    public boolean addPlayer(String clanId, UUID player) {
        var clan = clans.get(clanId);
        if (clan == null) return false;
        if (clan.members().size() >= clan.maxMembers()) return false;
        // Remove from previous clan first.
        var prev = playerToClan.get(player);
        if (prev != null) {
            var prevClan = clans.get(prev);
            if (prevClan != null) prevClan.members().remove(player);
        }
        clan.members().add(player);
        playerToClan.put(player, clanId);
        AsyncUtil.async(plugin, () -> { repo.upsertMember(player, clanId); return null; });
        return true;
    }

    public boolean removePlayer(UUID player) {
        var id = playerToClan.remove(player);
        if (id == null) return false;
        var c = clans.get(id);
        if (c != null) c.members().remove(player);
        AsyncUtil.async(plugin, () -> { repo.deleteMember(player); return null; });
        return true;
    }

    public boolean setName(String id, String name) {
        var c = clans.get(id);
        if (c == null) return false;
        c.setDisplayName(name);
        persist(c);
        return true;
    }

    public boolean setColor(String id, TextColor color) {
        var c = clans.get(id);
        if (c == null) return false;
        c.setColor(color);
        persist(c);
        return true;
    }

    public boolean setSpawn(String id, Location loc) {
        var c = clans.get(id);
        if (c == null) return false;
        c.setSpawn(loc);
        persist(c);
        return true;
    }

    public boolean setLeader(String id, OfflinePlayer player) {
        var c = clans.get(id);
        if (c == null) return false;
        c.setLeaderUuid(player.getUniqueId());
        if (!c.members().contains(player.getUniqueId())) {
            c.members().add(player.getUniqueId());
            playerToClan.put(player.getUniqueId(), id);
        }
        persist(c);
        return true;
    }

    public void awardPoints(String clanId, int delta) {
        var c = clans.get(clanId);
        if (c == null) return;
        c.addPoints(delta);
        persist(c);
        eventBus.publish(new ClanPointsChangedEvent(clanId, delta, c.points()));
    }

    public void flush() {
        for (var c : clans.values()) repo.upsert(c);
    }

    private void persist(Clan c) {
        AsyncUtil.async(plugin, () -> { repo.upsert(c); return null; });
    }

    public record ClanPointsChangedEvent(String clanId, int delta, int total) {}
}
