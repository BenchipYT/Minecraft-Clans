package com.mccore.respawn;

import com.mccore.clan.ClanService;
import com.mccore.config.ConfigService;
import com.mccore.event.EventService;
import com.mccore.territory.Region;
import com.mccore.territory.RegionService;
import com.mccore.territory.RegionType;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Respawn rules:
 * - During event: respawn at a clan-controlled BASE/CHECKPOINT/CASTLE.
 *   No controlled region → eliminate (spectator).
 * - After event: reactivate spectators back to survival.
 */
public final class RespawnService {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final ClanService clans;
    private final RegionService regions;
    private final EventService events;
    private final Set<UUID> eliminated = new HashSet<>();

    public RespawnService(JavaPlugin plugin, ConfigService config,
                          ClanService clans, RegionService regions, EventService events) {
        this.plugin = plugin;
        this.config = config;
        this.clans = clans;
        this.regions = regions;
        this.events = events;
    }

    public boolean isEliminated(UUID uuid) { return eliminated.contains(uuid); }

    public @Nullable Location pickRespawn(Player player) {
        var clan = clans.ofPlayer(player.getUniqueId());
        if (clan == null) return null;
        Region best = null;
        for (var r : regions.all()) {
            if (!r.respawnEnabled()) continue;
            if (!clan.id().equals(r.ownerClan())) continue;
            // priority: CASTLE > BASE > CHECKPOINT
            if (best == null || rank(r.type()) > rank(best.type())) best = r;
        }
        if (best == null) return clan.spawn();
        // For simplicity we hand back the clan spawn — region geometry comes from WG.
        // TODO: query a teleport anchor inside the WG region.
        return clan.spawn();
    }

    public void handleDeath(Player player) {
        if (!events.isRunning()) return;
        var loc = pickRespawn(player);
        if (loc == null) {
            eliminated.add(player.getUniqueId());
            if (config.main().getBoolean("respawn.spectator-on-elimination", true)) {
                player.setGameMode(GameMode.SPECTATOR);
            }
        }
    }

    public void reactivateAll() {
        for (var uuid : new HashSet<>(eliminated)) {
            var p = plugin.getServer().getPlayer(uuid);
            if (p != null) p.setGameMode(GameMode.SURVIVAL);
        }
        eliminated.clear();
    }

    private int rank(RegionType t) {
        return switch (t) { case CASTLE -> 3; case BASE -> 2; case CHECKPOINT -> 1; };
    }
}
