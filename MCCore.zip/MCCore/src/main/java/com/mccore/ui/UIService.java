package com.mccore.ui;

import com.mccore.clan.ClanService;
import com.mccore.config.ConfigService;
import com.mccore.config.MessageService;
import com.mccore.event.EventService;
import com.mccore.territory.RegionService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Comparator;

/**
 * Scoreboard / bossbar / actionbar coordinator.
 * Refreshes every config-defined interval; never per-tick.
 */
public final class UIService {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final MessageService messages;
    private final ClanService clans;
    private final EventService events;
    private final RegionService regions;
    private BukkitTask task;

    public UIService(JavaPlugin plugin, ConfigService config, MessageService messages,
                     ClanService clans, EventService events, RegionService regions) {
        this.plugin = plugin;
        this.config = config;
        this.messages = messages;
        this.clans = clans;
        this.events = events;
        this.regions = regions;
    }

    public void start() {
        if (task != null) return;
        var interval = Math.max(20L, config.main().getInt("ui.scoreboard.refresh-ticks", 20));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, interval);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    private void tick() {
        if (!config.main().getBoolean("ui.actionbar.enabled", true)) return;
        var sorted = clans.all().stream()
                .sorted(Comparator.comparingInt(c -> -c.points()))
                .toList();

        var sb = new StringBuilder("<gray>[MCC]</gray> ");
        for (var c : sorted) {
            sb.append("<color:").append(c.color().asHexString()).append(">")
              .append(c.displayName()).append("</color> <white>")
              .append(c.points()).append("</white>  ");
        }
        if (events.isRunning()) {
            var remaining = Math.max(0, events.endsAt() - System.currentTimeMillis()) / 1000;
            sb.append("<yellow>⏱ ").append(remaining / 60).append(":").append(String.format("%02d", remaining % 60)).append("</yellow>");
        }
        var line = messages.mini().deserialize(sb.toString());
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendActionBar(line);
        }
    }

    public Component greet(Player p) {
        return messages.get("event.starting-in");
    }
}
