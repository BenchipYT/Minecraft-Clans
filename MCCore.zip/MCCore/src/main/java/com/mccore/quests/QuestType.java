package com.mccore.quests;

public enum QuestType { MINING, FARMING, KILLS, CRAFTING, EXPLORATION }
