package com.mccore.quests;

import com.mccore.persistence.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public final class QuestRepository {

    public record Row(String clanId, String questId, int progress, boolean completed) {}

    private final DatabaseManager db;

    public QuestRepository(DatabaseManager db) { this.db = db; }

    public List<Row> loadAll() {
        var out = new ArrayList<Row>();
        try (Connection c = db.borrow();
             PreparedStatement ps = c.prepareStatement("SELECT clan_id, quest_id, progress, completed FROM mccore_quest_progress");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Row(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4) == 1));
            }
        } catch (SQLException e) { throw new RuntimeException("quest loadAll", e); }
        return out;
    }

    public void upsert(String clanId, String questId, int progress, boolean completed) {
        var sql = """
            INSERT INTO mccore_quest_progress (clan_id, quest_id, progress, completed) VALUES (?,?,?,?)
            ON CONFLICT(clan_id, quest_id) DO UPDATE SET progress=excluded.progress, completed=excluded.completed
            """;
        try (Connection c = db.borrow(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, clanId);
            ps.setString(2, questId);
            ps.setInt(3, progress);
            ps.setInt(4, completed ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("quest upsert", e); }
    }
}
