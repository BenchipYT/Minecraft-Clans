package com.mccore.quests;

import com.mccore.clan.ClanService;
import com.mccore.config.ConfigService;
import com.mccore.util.AsyncUtil;
import com.mccore.util.MCCEventBus;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Clan-wide quests with synchronized progress.
 * Skeleton: progress increments via {@link #progress(String, QuestType, int)}.
 */
public final class QuestService {

    public record QuestDefinition(String id, QuestType type, int goal, int rewardPoints) {}

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final ClanService clans;
    private final QuestRepository repo;
    private final MCCEventBus bus;

    private final Map<String, QuestDefinition> defs = new ConcurrentHashMap<>();
    /** clanId -> questId -> progress */
    private final Map<String, Map<String, Integer>> progress = new ConcurrentHashMap<>();

    public QuestService(JavaPlugin plugin, ConfigService config, ClanService clans,
                        QuestRepository repo, MCCEventBus bus) {
        this.plugin = plugin;
        this.config = config;
        this.clans = clans;
        this.repo = repo;
        this.bus = bus;
    }

    public void loadAll() {
        // TODO: load quest definitions from config (quests.yml).
        AsyncUtil.async(plugin, repo::loadAll).thenAccept(rows -> {
            for (var r : rows) {
                progress.computeIfAbsent(r.clanId(), k -> new ConcurrentHashMap<>())
                        .put(r.questId(), r.progress());
            }
        });
    }

    public void progress(String clanId, QuestType type, int amount) {
        defs.values().stream()
                .filter(d -> d.type() == type)
                .forEach(d -> {
                    var cur = progress.computeIfAbsent(clanId, k -> new ConcurrentHashMap<>())
                            .merge(d.id(), amount, Integer::sum);
                    if (cur >= d.goal()) {
                        clans.awardPoints(clanId, d.rewardPoints());
                        progress.get(clanId).remove(d.id()); // single-completion per event
                    }
                    AsyncUtil.async(plugin, () -> { repo.upsert(clanId, d.id(), cur, cur >= d.goal()); return null; });
                });
    }
}
