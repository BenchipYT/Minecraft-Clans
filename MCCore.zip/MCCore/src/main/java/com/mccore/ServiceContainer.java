package com.mccore;

import com.mccore.admin.AdminService;
import com.mccore.clan.ClanRepository;
import com.mccore.clan.ClanService;
import com.mccore.combat.CombatService;
import com.mccore.config.ConfigService;
import com.mccore.config.MessageService;
import com.mccore.event.EventScheduler;
import com.mccore.event.EventService;
import com.mccore.items.ClanItemRepository;
import com.mccore.items.ClanItemService;
import com.mccore.persistence.DatabaseManager;
import com.mccore.persistence.SchemaMigrator;
import com.mccore.quests.QuestRepository;
import com.mccore.quests.QuestService;
import com.mccore.respawn.RespawnService;
import com.mccore.territory.RegionRepository;
import com.mccore.territory.RegionService;
import com.mccore.territory.WorldGuardAdapter;
import com.mccore.ui.UIService;
import com.mccore.util.MCCEventBus;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Manual DI container. Keeps wiring explicit and inspectable.
 * One instance per plugin lifecycle.
 */
public final class ServiceContainer {

    private final JavaPlugin plugin;
    private final ConfigService configService;
    private final MessageService messageService;
    private final DatabaseManager database;
    private final MCCEventBus eventBus;

    private final ClanService clanService;
    private final RegionService regionService;
    private final WorldGuardAdapter worldGuard;
    private final EventService eventService;
    private final EventScheduler eventScheduler;
    private final CombatService combatService;
    private final RespawnService respawnService;
    private final ClanItemService clanItemService;
    private final QuestService questService;
    private final UIService uiService;
    private final AdminService adminService;

    private ServiceContainer(JavaPlugin plugin) {
        this.plugin = plugin;
        this.configService = new ConfigService(plugin);
        this.messageService = new MessageService(plugin, configService);
        this.eventBus = new MCCEventBus();

        this.database = new DatabaseManager(plugin, configService);
        this.database.connect();
        new SchemaMigrator(database).migrate();

        var clanRepo = new ClanRepository(database);
        var regionRepo = new RegionRepository(database);
        var itemRepo = new ClanItemRepository(database);
        var questRepo = new QuestRepository(database);

        this.clanService = new ClanService(plugin, configService, clanRepo, eventBus);
        this.worldGuard = new WorldGuardAdapter(plugin);
        this.regionService = new RegionService(plugin, configService, regionRepo, worldGuard, eventBus);

        this.eventService = new EventService(plugin, configService, eventBus);
        this.eventScheduler = new EventScheduler(plugin, configService, eventService);

        this.combatService = new CombatService(plugin, configService, clanService, eventService, eventBus);
        this.respawnService = new RespawnService(plugin, configService, clanService, regionService, eventService);
        this.clanItemService = new ClanItemService(plugin, configService, clanService, itemRepo);
        this.questService = new QuestService(plugin, configService, clanService, questRepo, eventBus);
        this.uiService = new UIService(plugin, configService, messageService, clanService, eventService, regionService);
        this.adminService = new AdminService(plugin, this);

        clanService.loadAll();
        regionService.loadAll();
        clanItemService.loadAll();
        questService.loadAll();
        uiService.start();
    }

    public static ServiceContainer bootstrap(JavaPlugin plugin) {
        return new ServiceContainer(plugin);
    }

    public JavaPlugin plugin() { return plugin; }
    public ConfigService config() { return configService; }
    public MessageService messages() { return messageService; }
    public DatabaseManager database() { return database; }
    public MCCEventBus eventBus() { return eventBus; }
    public ClanService clanService() { return clanService; }
    public RegionService regionService() { return regionService; }
    public WorldGuardAdapter worldGuard() { return worldGuard; }
    public EventService eventService() { return eventService; }
    public EventScheduler eventScheduler() { return eventScheduler; }
    public CombatService combatService() { return combatService; }
    public RespawnService respawnService() { return respawnService; }
    public ClanItemService clanItemService() { return clanItemService; }
    public QuestService questService() { return questService; }
    public UIService uiService() { return uiService; }
    public AdminService adminService() { return adminService; }
}
