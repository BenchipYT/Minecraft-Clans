package com.mccore;

import com.mccore.admin.AdminService;
import com.mccore.clan.ClanService;
import com.mccore.command.MCCCommand;
import com.mccore.config.ConfigService;
import com.mccore.config.MessageService;
import com.mccore.combat.CombatService;
import com.mccore.event.EventScheduler;
import com.mccore.event.EventService;
import com.mccore.items.ClanItemService;
import com.mccore.listener.CombatListener;
import com.mccore.listener.InventoryListener;
import com.mccore.listener.PlayerStateListener;
import com.mccore.listener.RegionListener;
import com.mccore.persistence.DatabaseManager;
import com.mccore.persistence.SchemaMigrator;
import com.mccore.quests.QuestService;
import com.mccore.respawn.RespawnService;
import com.mccore.territory.RegionService;
import com.mccore.territory.WorldGuardAdapter;
import com.mccore.ui.UIService;
import com.mccore.util.MCCEventBus;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Plugin bootstrap. Wires all services via constructor injection.
 * No business logic lives here — this class is intentionally thin.
 */
public final class MCCorePlugin extends JavaPlugin {

    private ServiceContainer services;

    @Override
    public void onEnable() {
        try {
            saveDefaultConfig();
            saveResource("clans.yml", false);
            saveResource("regions.yml", false);
            saveResource("messages.yml", false);

            this.services = ServiceContainer.bootstrap(this);

            registerListeners();
            registerCommands();

            services.eventScheduler().start();

            getLogger().info("MCCore enabled.");
        } catch (Exception ex) {
            getLogger().severe("Failed to enable MCCore: " + ex.getMessage());
            ex.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        if (services == null) return;
        try {
            services.eventScheduler().stop();
            services.eventService().shutdown();
            services.clanService().flush();
            services.regionService().flush();
            services.database().close();
        } catch (Exception ex) {
            getLogger().severe("Error during shutdown: " + ex.getMessage());
        }
        getLogger().info("MCCore disabled.");
    }

    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new CombatListener(services), this);
        pm.registerEvents(new InventoryListener(services), this);
        pm.registerEvents(new PlayerStateListener(services), this);
        pm.registerEvents(new RegionListener(services), this);
    }

    private void registerCommands() {
        var cmd = new MCCCommand(services);
        var registered = getCommand("mcc");
        if (registered != null) {
            registered.setExecutor(cmd);
            registered.setTabCompleter(cmd);
        }
    }

    public ServiceContainer services() {
        return services;
    }
}
