package com.mccore.command.sub;

import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface SubCommand {
    @Nullable default String permission() { return null; }
    boolean execute(CommandSender sender, String[] args);
    default List<String> tabComplete(CommandSender sender, String[] args) { return List.of(); }
}
