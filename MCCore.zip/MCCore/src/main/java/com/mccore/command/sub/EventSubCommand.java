package com.mccore.command.sub;

import com.mccore.ServiceContainer;
import org.bukkit.command.CommandSender;

import java.time.Duration;
import java.time.LocalTime;
import java.util.List;

public final class EventSubCommand implements SubCommand {

    private final ServiceContainer services;

    public EventSubCommand(ServiceContainer s) { this.services = s; }

    @Override public String permission() { return "mccore.event.manage"; }

    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length == 0) return usage(sender);
        var es = services.eventService();
        switch (args[0].toLowerCase()) {
            case "start", "forcestart" -> {
                var end = LocalTime.parse(services.config().main().getString("event.end", "18:00"));
                var dur = Duration.between(LocalTime.now(), end).toMillis();
                if (dur <= 0) dur = 60 * 60 * 1000L;
                es.start(dur);
                sender.sendMessage(services.messages().get("event.started"));
            }
            case "stop", "forcestop" -> {
                es.stop();
                sender.sendMessage(services.messages().get("event.ended"));
            }
            case "status" -> sender.sendMessage("§eState: " + es.state());
            default -> usage(sender);
        }
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender s, String[] a) {
        if (a.length == 1) return List.of("start", "stop", "status", "forcestart", "forcestop");
        return List.of();
    }

    private boolean usage(CommandSender s) {
        s.sendMessage("§eUsage: /mcc event <start|stop|status|forcestart|forcestop>");
        return true;
    }
}
