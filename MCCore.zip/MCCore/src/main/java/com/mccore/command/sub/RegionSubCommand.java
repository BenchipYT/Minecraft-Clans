package com.mccore.command.sub;

import com.mccore.ServiceContainer;
import com.mccore.territory.RegionType;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public final class RegionSubCommand implements SubCommand {

    private final ServiceContainer services;

    public RegionSubCommand(ServiceContainer s) { this.services = s; }

    @Override public String permission() { return "mccore.region.manage"; }

    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length == 0) return usage(sender);
        var rs = services.regionService();
        switch (args[0].toLowerCase()) {
            case "create" -> {
                if (args.length < 3) return usage(sender);
                RegionType t;
                try { t = RegionType.valueOf(args[2].toUpperCase()); }
                catch (Exception e) { sender.sendMessage("§cInvalid type."); return true; }
                var ok = rs.create(args[1], t, args[1]);
                sender.sendMessage(ok ? "§aRegion created." : "§cExists.");
            }
            case "delete" -> {
                if (args.length < 2) return usage(sender);
                rs.delete(args[1]);
                sender.sendMessage("§aRegion deleted.");
            }
            case "setwg" -> {
                if (args.length < 3) return usage(sender);
                var r = rs.get(args[1]); if (r == null) { sender.sendMessage("§cNo region."); return true; }
                r.setWorldGuardRegion(args[2]); rs.persist(r); sender.sendMessage("§aOK");
            }
            case "setname" -> {
                if (args.length < 3) return usage(sender);
                var r = rs.get(args[1]); if (r == null) { sender.sendMessage("§cNo region."); return true; }
                r.setDisplayName(joinFrom(args, 2)); rs.persist(r); sender.sendMessage("§aOK");
            }
            case "setowner" -> {
                if (args.length < 3) return usage(sender);
                var r = rs.get(args[1]); if (r == null) { sender.sendMessage("§cNo region."); return true; }
                r.setOwnerClan(args[2]); rs.persist(r); sender.sendMessage("§aOK");
            }
            case "setpoints" -> {
                if (args.length < 3) return usage(sender);
                var r = rs.get(args[1]); if (r == null) { sender.sendMessage("§cNo region."); return true; }
                try { r.setPointsPerMinute(Integer.parseInt(args[2])); rs.persist(r); sender.sendMessage("§aOK"); }
                catch (NumberFormatException e) { sender.sendMessage("§cNumber expected."); }
            }
            case "info" -> {
                if (args.length < 2) return usage(sender);
                var r = rs.get(args[1]); if (r == null) { sender.sendMessage("§cNo region."); return true; }
                sender.sendMessage("§e" + r.id() + " §7(" + r.type() + ") §fowner=" + r.ownerClan()
                        + " §fwg=" + r.worldGuardRegion() + " §fppm=" + r.pointsPerMinute());
            }
            case "list" -> {
                for (var r : rs.all()) {
                    sender.sendMessage("§e" + r.id() + " §7" + r.type() + " §fowner=" + r.ownerClan());
                }
            }
            default -> usage(sender);
        }
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender s, String[] a) {
        if (a.length == 1) return List.of("create", "delete", "setwg", "setname", "setowner", "setpoints", "info", "list");
        if (a.length == 2 && !a[0].equalsIgnoreCase("create")) {
            var out = new ArrayList<String>();
            for (var r : services.regionService().all()) out.add(r.id());
            return out;
        }
        if (a.length == 3 && a[0].equalsIgnoreCase("create")) {
            return List.of("BASE", "CHECKPOINT", "CASTLE");
        }
        return List.of();
    }

    private boolean usage(CommandSender s) {
        s.sendMessage("§eUsage: /mcc region <create|delete|setwg|setname|setowner|setpoints|info|list> ...");
        return true;
    }

    private String joinFrom(String[] a, int from) {
        var sb = new StringBuilder();
        for (int i = from; i < a.length; i++) { if (i > from) sb.append(' '); sb.append(a[i]); }
        return sb.toString();
    }
}
