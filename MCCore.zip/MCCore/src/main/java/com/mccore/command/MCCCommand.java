package com.mccore.command;

import com.mccore.ServiceContainer;
import com.mccore.command.sub.ClanSubCommand;
import com.mccore.command.sub.EventSubCommand;
import com.mccore.command.sub.RegionSubCommand;
import com.mccore.command.sub.SubCommand;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Root /mcc dispatcher. Subcommands implement {@link SubCommand}.
 */
public final class MCCCommand implements CommandExecutor, TabCompleter {

    private final ServiceContainer services;
    private final Map<String, SubCommand> subs;

    public MCCCommand(ServiceContainer services) {
        this.services = services;
        this.subs = Map.of(
                "clan",   new ClanSubCommand(services),
                "region", new RegionSubCommand(services),
                "event",  new EventSubCommand(services),
                "reload", new SubCommand() {
                    @Override public String permission() { return "mccore.admin"; }
                    @Override public boolean execute(CommandSender s, String[] a) {
                        services.adminService().reload();
                        s.sendMessage(services.messages().get("generic.reloaded"));
                        return true;
                    }
                },
                "save", new SubCommand() {
                    @Override public String permission() { return "mccore.admin"; }
                    @Override public boolean execute(CommandSender s, String[] a) {
                        services.adminService().save();
                        s.sendMessage("§aSaved.");
                        return true;
                    }
                },
                "debug", new SubCommand() {
                    @Override public String permission() { return "mccore.debug"; }
                    @Override public boolean execute(CommandSender s, String[] a) {
                        services.adminService().toggleDebug();
                        s.sendMessage("§eDebug toggled.");
                        return true;
                    }
                },
                "reset", new SubCommand() {
                    @Override public String permission() { return "mccore.admin"; }
                    @Override public boolean execute(CommandSender s, String[] a) {
                        services.adminService().resetSeason();
                        s.sendMessage("§cSeason reset.");
                        return true;
                    }
                }
        );
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§eUsage: /mcc <" + String.join("|", subs.keySet()) + ">");
            return true;
        }
        var sub = subs.get(args[0].toLowerCase());
        if (sub == null) {
            sender.sendMessage("§cUnknown subcommand.");
            return true;
        }
        if (sub.permission() != null && !sender.hasPermission(sub.permission())) {
            sender.sendMessage(services.messages().get("generic.no-permission"));
            return true;
        }
        return sub.execute(sender, Arrays.copyOfRange(args, 1, args.length));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return new ArrayList<>(subs.keySet());
        var sub = subs.get(args[0].toLowerCase());
        if (sub == null) return List.of();
        return sub.tabComplete(sender, Arrays.copyOfRange(args, 1, args.length));
    }
}
