package com.mccore.command.sub;

import com.mccore.ServiceContainer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ClanSubCommand implements SubCommand {

    private final ServiceContainer services;

    public ClanSubCommand(ServiceContainer s) { this.services = s; }

    @Override public String permission() { return "mccore.clan.manage"; }

    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length == 0) { usage(sender); return true; }
        var cs = services.clanService();
        var msg = services.messages();
        switch (args[0].toLowerCase()) {
            case "create" -> {
                if (args.length < 2) return usage(sender);
                var ok = cs.create(args[1], args[1], services.config().parseColor("WHITE"));
                sender.sendMessage(msg.get(ok ? "clan.created" : "clan.not-found", Map.of("id", args[1])));
            }
            case "delete" -> {
                if (args.length < 2) return usage(sender);
                cs.delete(args[1]);
                sender.sendMessage(msg.get("clan.deleted", Map.of("id", args[1])));
            }
            case "setname" -> {
                if (args.length < 3) return usage(sender);
                cs.setName(args[1], joinFrom(args, 2));
                sender.sendMessage("§aOK");
            }
            case "setcolor" -> {
                if (args.length < 3) return usage(sender);
                var color = services.config().parseColor(args[2]);
                if (color == null) { sender.sendMessage("§cInvalid color."); return true; }
                cs.setColor(args[1], color);
                sender.sendMessage("§aOK");
            }
            case "setspawn" -> {
                if (args.length < 2 || !(sender instanceof Player p)) {
                    sender.sendMessage(services.messages().get("generic.player-only"));
                    return true;
                }
                cs.setSpawn(args[1], p.getLocation());
                sender.sendMessage("§aSpawn set for " + args[1] + ".");
            }
            case "setleader" -> {
                if (args.length < 3) return usage(sender);
                var op = Bukkit.getOfflinePlayer(args[2]);
                cs.setLeader(args[1], op);
                sender.sendMessage("§aLeader set.");
            }
            case "addplayer" -> {
                if (args.length < 3) return usage(sender);
                var op = Bukkit.getOfflinePlayer(args[2]);
                var ok = cs.addPlayer(args[1], op.getUniqueId());
                sender.sendMessage(ok ? "§aAdded." : "§cFailed (full or unknown clan).");
            }
            case "removeplayer" -> {
                if (args.length < 2) return usage(sender);
                var op = Bukkit.getOfflinePlayer(args[1]);
                cs.removePlayer(op.getUniqueId());
                sender.sendMessage("§aRemoved.");
            }
            case "info" -> {
                if (args.length < 2) return usage(sender);
                var c = cs.get(args[1]);
                if (c == null) { sender.sendMessage(msg.get("clan.not-found", Map.of("id", args[1]))); return true; }
                sender.sendMessage(msg.get("clan.info", Map.of(
                        "color", c.color().asHexString(),
                        "name", c.displayName(),
                        "id", c.id(),
                        "members", String.valueOf(c.members().size()),
                        "max", String.valueOf(c.maxMembers()),
                        "points", String.valueOf(c.points())
                )));
            }
            case "list" -> {
                sender.sendMessage(msg.get("clan.list-header"));
                for (var c : cs.all()) {
                    sender.sendMessage(msg.get("clan.info", Map.of(
                            "color", c.color().asHexString(),
                            "name", c.displayName(),
                            "id", c.id(),
                            "members", String.valueOf(c.members().size()),
                            "max", String.valueOf(c.maxMembers()),
                            "points", String.valueOf(c.points())
                    )));
                }
            }
            default -> usage(sender);
        }
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender s, String[] a) {
        if (a.length == 1) return List.of("create", "delete", "setname", "setcolor", "setspawn",
                "setleader", "addplayer", "removeplayer", "info", "list");
        if (a.length == 2 && !a[0].equalsIgnoreCase("create")) {
            var out = new ArrayList<String>();
            for (var c : services.clanService().all()) out.add(c.id());
            return out;
        }
        return List.of();
    }

    private boolean usage(CommandSender s) {
        s.sendMessage("§eUsage: /mcc clan <create|delete|setname|setcolor|setspawn|setleader|addplayer|removeplayer|info|list> ...");
        return true;
    }

    private String joinFrom(String[] a, int from) {
        var sb = new StringBuilder();
        for (int i = from; i < a.length; i++) { if (i > from) sb.append(' '); sb.append(a[i]); }
        return sb.toString();
    }
}
