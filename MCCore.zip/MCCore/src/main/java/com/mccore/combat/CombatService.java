package com.mccore.combat;

import com.mccore.clan.ClanService;
import com.mccore.config.ConfigService;
import com.mccore.event.EventService;
import com.mccore.util.MCCEventBus;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kill scoring + anti-farm.
 * Per-event victim history → diminishing returns.
 * Per-(killer,victim) cooldown → kill-cooldown.
 */
public final class CombatService {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final ClanService clans;
    private final EventService events;
    private final MCCEventBus bus;

    /** killer → victim → last kill timestamp */
    private final Map<UUID, Map<UUID, Long>> lastKill = new ConcurrentHashMap<>();
    /** killer → victim → kills this event */
    private final Map<UUID, Map<UUID, Integer>> killsThisEvent = new ConcurrentHashMap<>();

    public CombatService(JavaPlugin plugin, ConfigService config,
                         ClanService clans, EventService events, MCCEventBus bus) {
        this.plugin = plugin;
        this.config = config;
        this.clans = clans;
        this.events = events;
        this.bus = bus;

        bus.subscribe(EventService.EventStartedEvent.class, e -> killsThisEvent.clear());
    }

    public void onKill(Player killer, Player victim) {
        if (!events.isRunning()) return;
        if (killer.getUniqueId().equals(victim.getUniqueId())) return;

        var killerClan = clans.ofPlayer(killer.getUniqueId());
        var victimClan = clans.ofPlayer(victim.getUniqueId());
        if (killerClan == null || victimClan == null) return;
        if (killerClan.id().equals(victimClan.id())) return; // no team-kill points

        var now = System.currentTimeMillis();
        var cdMs = config.killCooldownSeconds() * 1000L;
        var prev = lastKill.computeIfAbsent(killer.getUniqueId(), k -> new HashMap<>())
                .getOrDefault(victim.getUniqueId(), 0L);
        if (now - prev < cdMs) return;

        var streak = killsThisEvent.computeIfAbsent(killer.getUniqueId(), k -> new HashMap<>())
                .merge(victim.getUniqueId(), 1, Integer::sum);

        double factor = 1.0;
        if (config.diminishingEnabled()) {
            var arr = config.main().getDoubleList("anti-farm.diminishing-returns.factors");
            if (!arr.isEmpty()) {
                var idx = Math.min(streak - 1, arr.size() - 1);
                factor = arr.get(idx);
            }
        }
        var killPts = (int) Math.round(config.pointsKill() * factor);
        var deathPts = config.pointsDeath();

        if (killPts != 0) clans.awardPoints(killerClan.id(), killPts);
        if (deathPts != 0) clans.awardPoints(victimClan.id(), deathPts);

        lastKill.get(killer.getUniqueId()).put(victim.getUniqueId(), now);
    }
}
