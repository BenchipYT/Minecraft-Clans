package com.mccore.persistence;

import com.mccore.config.ConfigService;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.plugin.java.JavaPlugin;

import javax.sql.DataSource;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * HikariCP-backed connection pool. Supports SQLite and MySQL.
 */
public final class DatabaseManager {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private HikariDataSource dataSource;

    public DatabaseManager(JavaPlugin plugin, ConfigService config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void connect() {
        var hk = new HikariConfig();
        hk.setPoolName("MCCore-Pool");
        hk.setLeakDetectionThreshold(15_000);

        if ("mysql".equalsIgnoreCase(config.storageType())) {
            var c = config.main().getConfigurationSection("storage.mysql");
            hk.setJdbcUrl("jdbc:mysql://" + c.getString("host") + ":" + c.getInt("port")
                    + "/" + c.getString("database") + "?useSSL=false&characterEncoding=utf8");
            hk.setUsername(c.getString("username"));
            hk.setPassword(c.getString("password"));
            hk.setMaximumPoolSize(c.getInt("pool-size", 10));
            hk.setDriverClassName("com.mysql.cj.jdbc.Driver");
        } else {
            var file = new File(plugin.getDataFolder(),
                    config.main().getString("storage.sqlite.file", "data.db"));
            file.getParentFile().mkdirs();
            hk.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
            hk.setMaximumPoolSize(1); // SQLite: serialize writes
            hk.setDriverClassName("org.sqlite.JDBC");
        }

        this.dataSource = new HikariDataSource(hk);
        plugin.getLogger().info("Database connected (" + config.storageType() + ").");
    }

    public Connection borrow() throws SQLException {
        return dataSource.getConnection();
    }

    public DataSource dataSource() {
        return dataSource;
    }

    public boolean isMysql() {
        return "mysql".equalsIgnoreCase(config.storageType());
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) dataSource.close();
    }
}
