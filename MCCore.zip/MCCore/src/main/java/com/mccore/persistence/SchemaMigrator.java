package com.mccore.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Forward-only schema migration. Add new statements to MIGRATIONS.
 * SQL kept dialect-agnostic on purpose.
 */
public final class SchemaMigrator {

    private final DatabaseManager db;

    public SchemaMigrator(DatabaseManager db) { this.db = db; }

    private static final List<String> MIGRATIONS = List.of(
        // 1. clans
        """
        CREATE TABLE IF NOT EXISTS mccore_clans (
            id            VARCHAR(64)  PRIMARY KEY,
            display_name  VARCHAR(128) NOT NULL,
            color         VARCHAR(16)  NOT NULL,
            max_members   INT          NOT NULL DEFAULT 20,
            leader_uuid   VARCHAR(36),
            spawn_world   VARCHAR(64),
            spawn_x       DOUBLE,
            spawn_y       DOUBLE,
            spawn_z       DOUBLE,
            spawn_yaw     FLOAT,
            spawn_pitch   FLOAT,
            points        INT          NOT NULL DEFAULT 0
        )
        """,
        // 2. clan members
        """
        CREATE TABLE IF NOT EXISTS mccore_clan_members (
            uuid     VARCHAR(36) PRIMARY KEY,
            clan_id  VARCHAR(64) NOT NULL,
            joined_at BIGINT NOT NULL
        )
        """,
        // 3. regions
        """
        CREATE TABLE IF NOT EXISTS mccore_regions (
            id                  VARCHAR(64) PRIMARY KEY,
            display_name        VARCHAR(128) NOT NULL,
            type                VARCHAR(32)  NOT NULL,
            owner_clan          VARCHAR(64),
            wg_region           VARCHAR(128) NOT NULL,
            points_per_minute   INT NOT NULL DEFAULT 0,
            capture_enabled     INT NOT NULL DEFAULT 1,
            respawn_enabled     INT NOT NULL DEFAULT 1
        )
        """,
        // 4. clan items
        """
        CREATE TABLE IF NOT EXISTS mccore_clan_items (
            item_uuid  VARCHAR(36) PRIMARY KEY,
            slot_index INT NOT NULL,
            owner_clan VARCHAR(64),
            metadata   TEXT
        )
        """,
        // 5. quest progress
        """
        CREATE TABLE IF NOT EXISTS mccore_quest_progress (
            clan_id   VARCHAR(64) NOT NULL,
            quest_id  VARCHAR(64) NOT NULL,
            progress  INT NOT NULL DEFAULT 0,
            completed INT NOT NULL DEFAULT 0,
            PRIMARY KEY (clan_id, quest_id)
        )
        """,
        // 6. event state (single row, id=1)
        """
        CREATE TABLE IF NOT EXISTS mccore_event_state (
            id          INT PRIMARY KEY,
            running     INT NOT NULL DEFAULT 0,
            started_at  BIGINT,
            ends_at     BIGINT,
            season_day  INT NOT NULL DEFAULT 0
        )
        """,
        // 7. audit log
        """
        CREATE TABLE IF NOT EXISTS mccore_audit (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            ts        BIGINT NOT NULL,
            category  VARCHAR(32) NOT NULL,
            actor     VARCHAR(64),
            target    VARCHAR(64),
            payload   TEXT
        )
        """
    );

    public void migrate() {
        try (Connection c = db.borrow(); Statement st = c.createStatement()) {
            for (var sql : MIGRATIONS) {
                // SQLite dialect tweak for AUTOINCREMENT vs MySQL
                var dialectSql = db.isMysql()
                        ? sql.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "INT PRIMARY KEY AUTO_INCREMENT")
                        : sql;
                st.execute(dialectSql);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Schema migration failed", e);
        }
    }
}
