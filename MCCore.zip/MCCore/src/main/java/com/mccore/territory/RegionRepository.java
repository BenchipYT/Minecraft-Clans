package com.mccore.territory;

import com.mccore.persistence.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public final class RegionRepository {

    private final DatabaseManager db;

    public RegionRepository(DatabaseManager db) { this.db = db; }

    public List<Region> loadAll() {
        var out = new ArrayList<Region>();
        try (Connection c = db.borrow();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM mccore_regions");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                var r = new Region(rs.getString("id"),
                        RegionType.valueOf(rs.getString("type")),
                        rs.getString("display_name"),
                        rs.getString("wg_region"));
                r.setOwnerClan(rs.getString("owner_clan"));
                r.setPointsPerMinute(rs.getInt("points_per_minute"));
                r.setCaptureEnabled(rs.getInt("capture_enabled") == 1);
                r.setRespawnEnabled(rs.getInt("respawn_enabled") == 1);
                out.add(r);
            }
        } catch (SQLException e) { throw new RuntimeException("region loadAll", e); }
        return out;
    }

    public void upsert(Region r) {
        var sql = """
            INSERT INTO mccore_regions
              (id, display_name, type, owner_clan, wg_region, points_per_minute, capture_enabled, respawn_enabled)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              display_name=excluded.display_name,
              type=excluded.type,
              owner_clan=excluded.owner_clan,
              wg_region=excluded.wg_region,
              points_per_minute=excluded.points_per_minute,
              capture_enabled=excluded.capture_enabled,
              respawn_enabled=excluded.respawn_enabled
            """;
        try (Connection c = db.borrow(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.id());
            ps.setString(2, r.displayName());
            ps.setString(3, r.type().name());
            ps.setString(4, r.ownerClan());
            ps.setString(5, r.worldGuardRegion());
            ps.setInt(6, r.pointsPerMinute());
            ps.setInt(7, r.captureEnabled() ? 1 : 0);
            ps.setInt(8, r.respawnEnabled() ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("region upsert", e); }
    }

    public void delete(String id) {
        try (Connection c = db.borrow();
             PreparedStatement ps = c.prepareStatement("DELETE FROM mccore_regions WHERE id=?")) {
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("region delete", e); }
    }
}
