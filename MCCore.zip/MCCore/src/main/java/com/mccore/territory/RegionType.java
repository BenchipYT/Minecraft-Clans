package com.mccore.territory;

public enum RegionType { BASE, CHECKPOINT, CASTLE }
