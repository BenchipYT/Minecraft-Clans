package com.mccore.territory;

import com.mccore.config.ConfigService;
import com.mccore.persistence.DatabaseManager;
import com.mccore.util.AsyncUtil;
import com.mccore.util.MCCEventBus;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Region service. Tracks logical regions + their current owner.
 * Capture progress is tracked per-region in {@link CaptureState}.
 */
public final class RegionService {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final RegionRepository repo;
    private final WorldGuardAdapter wg;
    private final MCCEventBus eventBus;

    private final Map<String, Region> regions = new ConcurrentHashMap<>();
    private final Map<String, CaptureState> capture = new ConcurrentHashMap<>();

    public RegionService(JavaPlugin plugin, ConfigService config, RegionRepository repo,
                         WorldGuardAdapter wg, MCCEventBus eventBus) {
        this.plugin = plugin;
        this.config = config;
        this.repo = repo;
        this.wg = wg;
        this.eventBus = eventBus;
    }

    public void loadAll() {
        // Seed from regions.yml
        var section = config.regions().getConfigurationSection("regions");
        if (section != null) {
            for (var id : section.getKeys(false)) {
                var sec = section.getConfigurationSection(id);
                var r = new Region(id,
                        RegionType.valueOf(sec.getString("type", "BASE")),
                        sec.getString("display-name", id),
                        sec.getString("worldguard-region", id));
                r.setOwnerClan(sec.getString("owner-clan"));
                r.setPointsPerMinute(sec.getInt("points-per-minute", 0));
                r.setCaptureEnabled(sec.getBoolean("capture-enabled", true));
                r.setRespawnEnabled(sec.getBoolean("respawn-enabled", true));
                regions.put(id, r);
            }
        }
        AsyncUtil.async(plugin, repo::loadAll).thenAccept(loaded -> {
            for (var r : loaded) regions.put(r.id(), r);
            plugin.getLogger().info("Loaded " + regions.size() + " regions.");
        });
    }

    public Collection<Region> all() { return regions.values(); }
    public @Nullable Region get(String id) { return regions.get(id); }

    public boolean create(String id, RegionType type, String wgRegion) {
        if (regions.containsKey(id)) return false;
        var r = new Region(id, type, id, wgRegion);
        regions.put(id, r);
        AsyncUtil.async(plugin, () -> { repo.upsert(r); return null; });
        return true;
    }

    public boolean delete(String id) {
        if (regions.remove(id) == null) return false;
        capture.remove(id);
        AsyncUtil.async(plugin, () -> { repo.delete(id); return null; });
        return true;
    }

    public void persist(Region r) {
        AsyncUtil.async(plugin, () -> { repo.upsert(r); return null; });
    }

    public CaptureState captureFor(String regionId) {
        return capture.computeIfAbsent(regionId, id -> new CaptureState());
    }

    public void onCaptured(Region r, String newOwner) {
        var old = r.ownerClan();
        r.setOwnerClan(newOwner);
        persist(r);
        eventBus.publish(new RegionCapturedEvent(r.id(), old, newOwner));
    }

    public WorldGuardAdapter worldGuard() { return wg; }

    public void flush() {
        for (var r : regions.values()) repo.upsert(r);
    }

    public record RegionCapturedEvent(String regionId, @Nullable String oldOwner, String newOwner) {}

    /** Per-region transient capture state. */
    public static final class CaptureState {
        private double progress;       // 0..100
        private @Nullable String contender;

        public double progress() { return progress; }
        public void setProgress(double p) { this.progress = Math.max(0, Math.min(100, p)); }
        public @Nullable String contender() { return contender; }
        public void setContender(@Nullable String c) { this.contender = c; }
    }
}
