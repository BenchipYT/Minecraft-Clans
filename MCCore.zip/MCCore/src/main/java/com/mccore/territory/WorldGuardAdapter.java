package com.mccore.territory;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;

/**
 * Thin adapter over WorldGuard. We never re-implement geometry — we ask WG.
 */
public final class WorldGuardAdapter {

    private final JavaPlugin plugin;

    public WorldGuardAdapter(JavaPlugin plugin) { this.plugin = plugin; }

    public boolean available() {
        return plugin.getServer().getPluginManager().getPlugin("WorldGuard") != null;
    }

    public @Nullable ProtectedRegion getRegion(String world, String regionId) {
        if (!available()) return null;
        var w = plugin.getServer().getWorld(world);
        if (w == null) return null;
        var container = WorldGuard.getInstance().getPlatform().getRegionContainer();
        var manager = container.get(BukkitAdapter.adapt(w));
        return manager == null ? null : manager.getRegion(regionId);
    }

    public Set<String> regionsAt(Location loc) {
        var ids = new HashSet<String>();
        if (!available()) return ids;
        var container = WorldGuard.getInstance().getPlatform().getRegionContainer();
        var manager = container.get(BukkitAdapter.adapt(loc.getWorld()));
        if (manager == null) return ids;
        var set = manager.getApplicableRegions(BukkitAdapter.asBlockVector(loc));
        for (var r : set) ids.add(r.getId());
        return ids;
    }
}
