package com.mccore.territory;

import org.jetbrains.annotations.Nullable;

public final class Region {
    private final String id;
    private String displayName;
    private RegionType type;
    private @Nullable String ownerClan;
    private String worldGuardRegion;
    private int pointsPerMinute;
    private boolean captureEnabled;
    private boolean respawnEnabled;

    public Region(String id, RegionType type, String displayName, String wgRegion) {
        this.id = id;
        this.type = type;
        this.displayName = displayName;
        this.worldGuardRegion = wgRegion;
        this.captureEnabled = true;
        this.respawnEnabled = true;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public void setDisplayName(String n) { this.displayName = n; }
    public RegionType type() { return type; }
    public void setType(RegionType t) { this.type = t; }
    public @Nullable String ownerClan() { return ownerClan; }
    public void setOwnerClan(@Nullable String c) { this.ownerClan = c; }
    public String worldGuardRegion() { return worldGuardRegion; }
    public void setWorldGuardRegion(String w) { this.worldGuardRegion = w; }
    public int pointsPerMinute() { return pointsPerMinute; }
    public void setPointsPerMinute(int p) { this.pointsPerMinute = p; }
    public boolean captureEnabled() { return captureEnabled; }
    public void setCaptureEnabled(boolean b) { this.captureEnabled = b; }
    public boolean respawnEnabled() { return respawnEnabled; }
    public void setRespawnEnabled(boolean b) { this.respawnEnabled = b; }
}
