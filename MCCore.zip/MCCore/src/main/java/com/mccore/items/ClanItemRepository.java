package com.mccore.items;

import com.mccore.persistence.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ClanItemRepository {

    public record Row(UUID uuid, int slot, String clanId) {}

    private final DatabaseManager db;

    public ClanItemRepository(DatabaseManager db) { this.db = db; }

    public List<Row> loadAll() {
        var out = new ArrayList<Row>();
        try (Connection c = db.borrow();
             PreparedStatement ps = c.prepareStatement("SELECT item_uuid, slot_index, owner_clan FROM mccore_clan_items");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Row(UUID.fromString(rs.getString(1)), rs.getInt(2), rs.getString(3)));
            }
        } catch (SQLException e) { throw new RuntimeException("clanItem loadAll", e); }
        return out;
    }

    public void upsert(UUID uuid, int slot, String clanId) {
        var sql = """
            INSERT INTO mccore_clan_items (item_uuid, slot_index, owner_clan, metadata)
            VALUES (?,?,?,?)
            ON CONFLICT(item_uuid) DO UPDATE SET slot_index=excluded.slot_index, owner_clan=excluded.owner_clan
            """;
        try (Connection c = db.borrow(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setInt(2, slot);
            ps.setString(3, clanId);
            ps.setString(4, null);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("clanItem upsert", e); }
    }
}
