package com.mccore.items;

import com.mccore.clan.Clan;
import com.mccore.clan.ClanService;
import com.mccore.config.ConfigService;
import com.mccore.util.AsyncUtil;
import org.bukkit.NamespacedKey;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 8 globally unique clan special items. Identity = UUID baked into the
 * ItemStack via PersistentDataContainer. Ownership is tracked here.
 *
 * Anti-dupe strategy:
 *  - PDC UUID + DB row are paired; on pickup we verify both.
 *  - Movement listeners reject hopper/itemframe/death-drop unless allowed.
 *  - On clan-bound mode, drops re-route to the clan stash (TODO).
 */
public final class ClanItemService {

    public static final NamespacedKey ITEM_KEY = NamespacedKey.minecraft("mccore_special");

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final ClanService clans;
    private final ClanItemRepository repo;

    /** UUID → owning clan id (null = unowned but exists). */
    private final Map<UUID, String> ownership = new ConcurrentHashMap<>();
    /** UUID → slot index (1..N). */
    private final Map<UUID, Integer> slot = new ConcurrentHashMap<>();

    public ClanItemService(JavaPlugin plugin, ConfigService config,
                           ClanService clans, ClanItemRepository repo) {
        this.plugin = plugin;
        this.config = config;
        this.clans = clans;
        this.repo = repo;
    }

    public void loadAll() {
        AsyncUtil.async(plugin, repo::loadAll).thenAccept(rows -> {
            for (var row : rows) {
                ownership.put(row.uuid(), row.clanId());
                slot.put(row.uuid(), row.slot());
            }
        });
    }

    public ItemStack mint(int slotIndex, Material material) {
        var stack = new ItemStack(material);
        var meta = stack.getItemMeta();
        var uuid = UUID.randomUUID();
        meta.getPersistentDataContainer().set(ITEM_KEY, PersistentDataType.STRING, uuid.toString());
        stack.setItemMeta(meta);
        ownership.put(uuid, null);
        slot.put(uuid, slotIndex);
        AsyncUtil.async(plugin, () -> { repo.upsert(uuid, slotIndex, null); return null; });
        return stack;
    }

    public @Nullable UUID readUuid(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        var raw = stack.getItemMeta().getPersistentDataContainer()
                .get(ITEM_KEY, PersistentDataType.STRING);
        try { return raw == null ? null : UUID.fromString(raw); }
        catch (IllegalArgumentException e) { return null; }
    }

    public boolean isClanItem(ItemStack stack) {
        return readUuid(stack) != null;
    }

    public boolean transferTo(UUID itemUuid, @Nullable String clanId) {
        if (!ownership.containsKey(itemUuid)) return false;
        // Each clan max 1 item.
        if (clanId != null) {
            for (var entry : ownership.entrySet()) {
                if (clanId.equals(entry.getValue())) return false;
            }
        }
        ownership.put(itemUuid, clanId);
        AsyncUtil.async(plugin, () -> { repo.upsert(itemUuid, slot.getOrDefault(itemUuid, -1), clanId); return null; });
        return true;
    }

    public @Nullable String ownerOf(UUID itemUuid) {
        return ownership.get(itemUuid);
    }
}
