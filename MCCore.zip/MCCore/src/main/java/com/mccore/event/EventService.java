package com.mccore.event;

import com.mccore.config.ConfigService;
import com.mccore.util.MCCEventBus;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Event runtime state. Crash-recoverable via persisted {@code mccore_event_state} row.
 */
public final class EventService {

    public enum State { IDLE, COUNTDOWN, RUNNING, ENDED }

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final MCCEventBus eventBus;
    private final AtomicReference<State> state = new AtomicReference<>(State.IDLE);

    private long startedAt;
    private long endsAt;

    public EventService(JavaPlugin plugin, ConfigService config, MCCEventBus eventBus) {
        this.plugin = plugin;
        this.config = config;
        this.eventBus = eventBus;
    }

    public State state() { return state.get(); }
    public boolean isRunning() { return state.get() == State.RUNNING; }
    public long startedAt() { return startedAt; }
    public long endsAt() { return endsAt; }

    public void start(long durationMs) {
        if (!state.compareAndSet(State.IDLE, State.RUNNING)
                && !state.compareAndSet(State.COUNTDOWN, State.RUNNING)) return;
        startedAt = System.currentTimeMillis();
        endsAt = startedAt + durationMs;
        eventBus.publish(new EventStartedEvent(startedAt, endsAt));
        plugin.getLogger().info("Event started.");
    }

    public void stop() {
        var prev = state.getAndSet(State.ENDED);
        if (prev == State.RUNNING || prev == State.COUNTDOWN) {
            eventBus.publish(new EventEndedEvent(System.currentTimeMillis()));
            plugin.getLogger().info("Event stopped.");
        }
    }

    public void resetIdle() { state.set(State.IDLE); }

    public void shutdown() {
        if (isRunning()) stop();
    }

    public record EventStartedEvent(long startedAt, long endsAt) {}
    public record EventEndedEvent(long endedAt) {}
}
