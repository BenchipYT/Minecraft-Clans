package com.mccore.event;

import com.mccore.config.ConfigService;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Schedules the weekly event (default Saturday 14:00–18:00).
 * Uses a single repeating task that polls every 30s — no thread spam.
 */
public final class EventScheduler {

    private final JavaPlugin plugin;
    private final ConfigService config;
    private final EventService eventService;
    private BukkitTask task;

    public EventScheduler(JavaPlugin plugin, ConfigService config, EventService eventService) {
        this.plugin = plugin;
        this.config = config;
        this.eventService = eventService;
    }

    public void start() {
        if (task != null) return;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L * 10, 20L * 30);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    private void tick() {
        if (!config.main().getBoolean("event.auto-start", true)) return;
        var now = LocalDateTime.now();
        var day = DayOfWeek.valueOf(config.main().getString("event.day", "SATURDAY"));
        if (now.getDayOfWeek() != day) return;

        var start = LocalTime.parse(config.main().getString("event.start", "14:00"));
        var end   = LocalTime.parse(config.main().getString("event.end", "18:00"));

        if (eventService.state() == EventService.State.IDLE
                && !now.toLocalTime().isBefore(start)
                && now.toLocalTime().isBefore(end)) {
            var remaining = Duration.between(now.toLocalTime(), end).toMillis();
            eventService.start(remaining);
        } else if (eventService.isRunning() && !now.toLocalTime().isBefore(end)) {
            eventService.stop();
        }
    }
}
