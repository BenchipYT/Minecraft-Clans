package com.mccore.admin;

import com.mccore.ServiceContainer;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Admin operations: reload, save, debug, reset.
 */
public final class AdminService {

    private final JavaPlugin plugin;
    private final ServiceContainer services;

    public AdminService(JavaPlugin plugin, ServiceContainer services) {
        this.plugin = plugin;
        this.services = services;
    }

    public void reload() {
        services.config().reload();
        services.messages().reload();
    }

    public void save() {
        services.clanService().flush();
        services.regionService().flush();
        services.config().saveClans();
        services.config().saveRegions();
    }

    public void toggleDebug() {
        var cur = services.config().main().getBoolean("debug", false);
        services.config().main().set("debug", !cur);
        plugin.saveConfig();
    }

    public void resetSeason() {
        for (var c : services.clanService().all()) c.setPoints(0);
        services.clanService().flush();
        // TODO: clear quest progress + audit if a true hard reset is requested.
    }
}
