package com.mccore;

import com.mccore.util.MCCEventBus;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MCCEventBusTest {

    record Ping(int n) {}

    @Test
    void deliversToSubscribers() {
        var bus = new MCCEventBus();
        var hits = new AtomicInteger();
        bus.subscribe(Ping.class, p -> hits.addAndGet(p.n()));
        bus.publish(new Ping(2));
        bus.publish(new Ping(3));
        assertEquals(5, hits.get());
    }

    @Test
    void unrelatedEventsIgnored() {
        var bus = new MCCEventBus();
        var hits = new AtomicInteger();
        bus.subscribe(Ping.class, p -> hits.incrementAndGet());
        bus.publish("string");
        assertEquals(0, hits.get());
    }
}
