package com.mccore;

import com.mccore.util.ColorParser;
import net.kyori.adventure.text.format.NamedTextColor;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ColorParserTest {

    @Test
    void parsesNamed() {
        assertEquals(NamedTextColor.RED, ColorParser.parse("RED"));
        assertEquals(NamedTextColor.BLUE, ColorParser.parse("blue"));
    }

    @Test
    void parsesHex() {
        var c = ColorParser.parse("#FFAA00");
        assertNotNull(c);
        assertEquals("#ffaa00", c.asHexString());
    }

    @Test
    void rejectsGarbage() {
        assertNull(ColorParser.parse(""));
        assertNull(ColorParser.parse(null));
        assertNull(ColorParser.parse("#NOTAHEX"));
    }
}
